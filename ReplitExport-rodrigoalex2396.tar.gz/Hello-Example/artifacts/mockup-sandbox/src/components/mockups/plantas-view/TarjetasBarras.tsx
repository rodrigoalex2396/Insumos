import { useState } from "react";
import { Wifi, Router, Radio, Timer, Zap, Cable, Cpu, Signal } from "lucide-react";

const TIPOS = [
  { key: "SIM", label: "SIM", icon: Signal, color: "#EAB308" },
  { key: "DONGLE", label: "Dongle", icon: Cpu, color: "#F97316" },
  { key: "SMARTLOGGER", label: "SmartLogger", icon: Wifi, color: "#22C55E" },
  { key: "ROUTER", label: "Router", icon: Router, color: "#3B82F6" },
  { key: "ANTENA", label: "Antena", icon: Radio, color: "#8B5CF6" },
  { key: "TIMER_DIGITAL", label: "Timer", icon: Timer, color: "#EC4899" },
  { key: "REGULADOR_TENSION", label: "Regulador", icon: Zap, color: "#14B8A6" },
  { key: "CABLE_COMUNICACION", label: "Cable", icon: Cable, color: "#6B7280" },
];

const PLANTAS = [
  {
    nombre: "Altamira Norte",
    fv: "FV-001",
    cobertura: "Alta",
    items: { SIM: 4, DONGLE: 2, SMARTLOGGER: 1, ROUTER: 2, ANTENA: 3, TIMER_DIGITAL: 0, REGULADOR_TENSION: 1, CABLE_COMUNICACION: 120 },
    total: 13,
  },
  {
    nombre: "Central Sur",
    fv: "FV-002",
    cobertura: "Media",
    items: { SIM: 6, DONGLE: 1, SMARTLOGGER: 2, ROUTER: 1, ANTENA: 2, TIMER_DIGITAL: 2, REGULADOR_TENSION: 0, CABLE_COMUNICACION: 85 },
    total: 14,
  },
  {
    nombre: "Parque Solar Lomas",
    fv: "FV-003",
    cobertura: "Alta",
    items: { SIM: 8, DONGLE: 3, SMARTLOGGER: 2, ROUTER: 3, ANTENA: 4, TIMER_DIGITAL: 1, REGULADOR_TENSION: 2, CABLE_COMUNICACION: 240 },
    total: 23,
  },
  {
    nombre: "Estación Rivero",
    fv: "FV-004",
    cobertura: "Baja",
    items: { SIM: 2, DONGLE: 1, SMARTLOGGER: 1, ROUTER: 0, ANTENA: 1, TIMER_DIGITAL: 0, REGULADOR_TENSION: 1, CABLE_COMUNICACION: 30 },
    total: 6,
  },
  {
    nombre: "Parque Vientos del Sur",
    fv: "FV-005",
    cobertura: "Alta",
    items: { SIM: 5, DONGLE: 2, SMARTLOGGER: 3, ROUTER: 2, ANTENA: 5, TIMER_DIGITAL: 2, REGULADOR_TENSION: 2, CABLE_COMUNICACION: 180 },
    total: 21,
  },
];

const COBERTURAS: Record<string, { label: string; bg: string; text: string }> = {
  Alta: { label: "ALTA", bg: "bg-green-500/15", text: "text-green-400" },
  Media: { label: "MEDIA", bg: "bg-yellow-500/15", text: "text-yellow-400" },
  Baja: { label: "BAJA", bg: "bg-red-500/15", text: "text-red-400" },
};

const maxTotal = Math.max(...PLANTAS.map((p) => p.total));

export function TarjetasBarras() {
  const [selected, setSelected] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-[#0D0D0D] text-white font-mono p-6">
      {/* Header */}
      <div className="mb-8 flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="w-2 h-2 rounded-full bg-yellow-400 animate-pulse" />
            <span className="text-xs text-yellow-400 tracking-widest uppercase">SolarStock</span>
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white">Resumen por Planta</h1>
          <p className="text-xs text-gray-500 mt-0.5 uppercase tracking-wider">{PLANTAS.length} plantas · {PLANTAS.reduce((a, p) => a + p.total, 0)} equipos registrados</p>
        </div>
        <div className="text-right">
          <div className="text-3xl font-bold text-yellow-400">{PLANTAS.length}</div>
          <div className="text-xs text-gray-500 uppercase tracking-wider">Plantas activas</div>
        </div>
      </div>

      {/* Cards grid */}
      <div className="grid gap-4">
        {PLANTAS.map((planta) => {
          const cob = COBERTURAS[planta.cobertura];
          const isSelected = selected === planta.nombre;
          return (
            <div
              key={planta.nombre}
              onClick={() => setSelected(isSelected ? null : planta.nombre)}
              className={`border rounded-none cursor-pointer transition-all ${
                isSelected
                  ? "border-yellow-400/60 bg-yellow-400/5"
                  : "border-gray-800 bg-[#141414] hover:border-gray-600"
              }`}
            >
              <div className="p-4">
                {/* Plant header */}
                <div className="flex items-start justify-between mb-3">
                  <div>
                    <div className="font-bold text-sm text-white tracking-wide">{planta.nombre}</div>
                    <div className="text-xs text-gray-500 mt-0.5">{planta.fv}</div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-none uppercase tracking-widest ${cob.bg} ${cob.text}`}>
                      {cob.label}
                    </span>
                    <span className="text-xs text-gray-400 font-bold">{planta.total} equipos</span>
                  </div>
                </div>

                {/* Total bar */}
                <div className="mb-3">
                  <div className="h-1.5 bg-gray-800 rounded-none overflow-hidden">
                    <div
                      className="h-full bg-yellow-400 transition-all duration-500"
                      style={{ width: `${(planta.total / maxTotal) * 100}%` }}
                    />
                  </div>
                </div>

                {/* Type breakdown */}
                <div className="grid grid-cols-4 gap-2">
                  {TIPOS.map((tipo) => {
                    const val = planta.items[tipo.key as keyof typeof planta.items];
                    if (val === 0) return null;
                    const Icon = tipo.icon;
                    return (
                      <div key={tipo.key} className="flex flex-col gap-1">
                        <div className="flex items-center gap-1">
                          <Icon size={10} style={{ color: tipo.color }} />
                          <span className="text-[9px] text-gray-500 uppercase tracking-wider truncate">{tipo.label}</span>
                        </div>
                        <div className="h-1 bg-gray-800 rounded-none overflow-hidden">
                          <div
                            className="h-full rounded-none"
                            style={{
                              width: `${Math.min(100, (val / 10) * 100)}%`,
                              backgroundColor: tipo.color,
                              opacity: 0.8,
                            }}
                          />
                        </div>
                        <span className="text-[10px] font-bold" style={{ color: tipo.color }}>
                          {tipo.key === "CABLE_COMUNICACION" ? `${val}m` : val}
                        </span>
                      </div>
                    );
                  })}
                </div>

                {/* Expanded detail */}
                {isSelected && (
                  <div className="mt-4 pt-4 border-t border-gray-800">
                    <div className="text-[10px] text-gray-500 uppercase tracking-widest mb-3">Desglose completo</div>
                    <div className="grid grid-cols-2 gap-x-6 gap-y-1.5">
                      {TIPOS.map((tipo) => {
                        const val = planta.items[tipo.key as keyof typeof planta.items];
                        const Icon = tipo.icon;
                        return (
                          <div key={tipo.key} className="flex items-center justify-between">
                            <div className="flex items-center gap-1.5">
                              <Icon size={11} style={{ color: tipo.color }} />
                              <span className="text-[11px] text-gray-400">{tipo.label}</span>
                            </div>
                            <span className="text-[11px] font-bold" style={{ color: val > 0 ? tipo.color : "#374151" }}>
                              {tipo.key === "CABLE_COMUNICACION" ? `${val}m` : val}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Legend */}
      <div className="mt-6 pt-4 border-t border-gray-800 flex flex-wrap gap-4">
        {TIPOS.map((tipo) => {
          const Icon = tipo.icon;
          return (
            <div key={tipo.key} className="flex items-center gap-1.5">
              <Icon size={10} style={{ color: tipo.color }} />
              <span className="text-[10px] text-gray-500 uppercase tracking-wide">{tipo.label}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
