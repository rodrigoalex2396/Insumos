import { useState } from "react";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts";
import { ChevronDown, ChevronRight, Layers, TrendingUp } from "lucide-react";

const TIPOS_CONFIG = [
  { key: "SIM", label: "SIM", color: "#EAB308" },
  { key: "DONGLE", label: "Dongle", color: "#F97316" },
  { key: "SMARTLOGGER", label: "SmartLogger", color: "#22C55E" },
  { key: "ROUTER", label: "Router", color: "#3B82F6" },
  { key: "ANTENA", label: "Antena", color: "#8B5CF6" },
  { key: "TIMER_DIGITAL", label: "Timer Digital", color: "#EC4899" },
  { key: "REGULADOR_TENSION", label: "Regulador", color: "#14B8A6" },
  { key: "CABLE_COMUNICACION", label: "Cable (m)", color: "#6B7280" },
];

const PLANTAS = [
  { nombre: "Altamira Norte", fv: "FV-001", cobertura: "Alta", items: { SIM: 4, DONGLE: 2, SMARTLOGGER: 1, ROUTER: 2, ANTENA: 3, TIMER_DIGITAL: 0, REGULADOR_TENSION: 1, CABLE_COMUNICACION: 120 } },
  { nombre: "Central Sur", fv: "FV-002", cobertura: "Media", items: { SIM: 6, DONGLE: 1, SMARTLOGGER: 2, ROUTER: 1, ANTENA: 2, TIMER_DIGITAL: 2, REGULADOR_TENSION: 0, CABLE_COMUNICACION: 85 } },
  { nombre: "Parque Solar Lomas", fv: "FV-003", cobertura: "Alta", items: { SIM: 8, DONGLE: 3, SMARTLOGGER: 2, ROUTER: 3, ANTENA: 4, TIMER_DIGITAL: 1, REGULADOR_TENSION: 2, CABLE_COMUNICACION: 240 } },
  { nombre: "Estación Rivero", fv: "FV-004", cobertura: "Baja", items: { SIM: 2, DONGLE: 1, SMARTLOGGER: 1, ROUTER: 0, ANTENA: 1, TIMER_DIGITAL: 0, REGULADOR_TENSION: 1, CABLE_COMUNICACION: 30 } },
  { nombre: "Parque Vientos del Sur", fv: "FV-005", cobertura: "Alta", items: { SIM: 5, DONGLE: 2, SMARTLOGGER: 3, ROUTER: 2, ANTENA: 5, TIMER_DIGITAL: 2, REGULADOR_TENSION: 2, CABLE_COMUNICACION: 180 } },
];

// Global totals for the donut
const globalTotals = TIPOS_CONFIG.map((t) => ({
  name: t.label,
  value: PLANTAS.reduce((sum, p) => sum + (p.items[t.key as keyof typeof p.items] || 0), 0),
  color: t.color,
  key: t.key,
})).filter((t) => t.value > 0);

const totalEquipos = PLANTAS.reduce((sum, p) => sum + Object.values(p.items).reduce((a, b) => a + b, 0), 0);

const COB_DOT: Record<string, string> = {
  Alta: "bg-green-400",
  Media: "bg-yellow-400",
  Baja: "bg-red-400",
};

export function ListaDonut() {
  const [expanded, setExpanded] = useState<string | null>("Parque Solar Lomas");

  return (
    <div className="min-h-screen bg-[#111827] text-white font-sans p-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold tracking-tight mb-1">Plantas Fotovoltaicas</h1>
        <p className="text-sm text-gray-400">{PLANTAS.length} plantas · {totalEquipos} equipos totales</p>
      </div>

      <div className="grid grid-cols-[1fr_300px] gap-8">
        {/* Left — expandable list */}
        <div className="space-y-2">
          {PLANTAS.map((planta) => {
            const isOpen = expanded === planta.nombre;
            const total = Object.values(planta.items).reduce((a, b) => a + b, 0);
            const pieData = TIPOS_CONFIG
              .filter((t) => planta.items[t.key as keyof typeof planta.items] > 0)
              .map((t) => ({ name: t.label, value: planta.items[t.key as keyof typeof planta.items], color: t.color }));

            return (
              <div key={planta.nombre} className={`rounded-xl border transition-all ${isOpen ? "border-blue-500/40 bg-blue-500/5" : "border-gray-700/50 bg-gray-800/30"}`}>
                <button
                  onClick={() => setExpanded(isOpen ? null : planta.nombre)}
                  className="w-full flex items-center justify-between p-4 text-left"
                >
                  <div className="flex items-center gap-3">
                    {isOpen ? <ChevronDown size={16} className="text-blue-400" /> : <ChevronRight size={16} className="text-gray-500" />}
                    <div>
                      <div className="font-semibold text-sm">{planta.nombre}</div>
                      <div className="flex items-center gap-2 mt-0.5">
                        <span className="text-xs text-gray-500">{planta.fv}</span>
                        <span className="text-gray-700">·</span>
                        <span className={`w-1.5 h-1.5 rounded-full inline-block ${COB_DOT[planta.cobertura]}`} />
                        <span className="text-xs text-gray-500">Cobertura {planta.cobertura}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {/* Mini stacked bar */}
                    <div className="flex h-2 w-24 overflow-hidden rounded-full bg-gray-700">
                      {pieData.map((d) => (
                        <div
                          key={d.name}
                          style={{ width: `${(d.value / total) * 100}%`, backgroundColor: d.color }}
                          className="h-full"
                        />
                      ))}
                    </div>
                    <span className="text-sm font-bold text-gray-300">{total}</span>
                  </div>
                </button>

                {isOpen && (
                  <div className="px-4 pb-4 grid grid-cols-2 gap-x-6 gap-y-1.5 border-t border-gray-700/50 pt-4">
                    {TIPOS_CONFIG.map((tipo) => {
                      const val = planta.items[tipo.key as keyof typeof planta.items];
                      return (
                        <div key={tipo.key} className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <div className="w-2 h-2 rounded-full" style={{ backgroundColor: tipo.color }} />
                            <span className="text-xs text-gray-400">{tipo.label}</span>
                          </div>
                          <span className={`text-xs font-semibold ${val > 0 ? "text-white" : "text-gray-600"}`}>
                            {tipo.key === "CABLE_COMUNICACION" ? `${val}m` : val}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Right — donut chart */}
        <div className="space-y-4">
          <div className="rounded-xl border border-gray-700/50 bg-gray-800/30 p-5">
            <div className="flex items-center gap-2 mb-4">
              <Layers size={14} className="text-blue-400" />
              <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Total global</span>
            </div>
            <div className="relative h-44">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={globalTotals}
                    cx="50%"
                    cy="50%"
                    innerRadius={52}
                    outerRadius={70}
                    paddingAngle={3}
                    dataKey="value"
                  >
                    {globalTotals.map((entry) => (
                      <Cell key={entry.key} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ background: "#1F2937", border: "1px solid #374151", borderRadius: 8, fontSize: 12 }}
                    itemStyle={{ color: "#E5E7EB" }}
                  />
                </PieChart>
              </ResponsiveContainer>
              {/* Center label */}
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <span className="text-2xl font-bold">{totalEquipos}</span>
                <span className="text-[10px] text-gray-500 uppercase tracking-wider">total</span>
              </div>
            </div>
            {/* Legend */}
            <div className="mt-4 space-y-1.5">
              {globalTotals.map((t) => (
                <div key={t.key} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full" style={{ backgroundColor: t.color }} />
                    <span className="text-xs text-gray-400">{t.name}</span>
                  </div>
                  <span className="text-xs font-semibold text-white">
                    {t.key === "CABLE_COMUNICACION" ? `${t.value}m` : t.value}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Stats */}
          <div className="rounded-xl border border-gray-700/50 bg-gray-800/30 p-4">
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp size={14} className="text-green-400" />
              <span className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Cobertura</span>
            </div>
            {["Alta", "Media", "Baja"].map((cob) => {
              const count = PLANTAS.filter((p) => p.cobertura === cob).length;
              return (
                <div key={cob} className="flex items-center justify-between mb-2 last:mb-0">
                  <div className="flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${COB_DOT[cob]}`} />
                    <span className="text-xs text-gray-400">{cob}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="h-1 w-16 bg-gray-700 rounded-full overflow-hidden">
                      <div className={`h-full rounded-full ${COB_DOT[cob]}`} style={{ width: `${(count / PLANTAS.length) * 100}%` }} />
                    </div>
                    <span className="text-xs font-bold text-white w-4 text-right">{count}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
