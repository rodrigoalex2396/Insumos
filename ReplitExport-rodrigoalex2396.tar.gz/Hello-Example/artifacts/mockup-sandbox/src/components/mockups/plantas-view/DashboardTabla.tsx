import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from "recharts";
import { Signal, Cpu, Wifi, Router, Radio, Timer, Zap, Cable } from "lucide-react";

const TIPOS = [
  { key: "SIM", label: "SIM", icon: Signal, color: "#EAB308" },
  { key: "DONGLE", label: "Dongle", icon: Cpu, color: "#F97316" },
  { key: "SMARTLOGGER", label: "SL", icon: Wifi, color: "#22C55E" },
  { key: "ROUTER", label: "Router", icon: Router, color: "#3B82F6" },
  { key: "ANTENA", label: "Antena", icon: Radio, color: "#8B5CF6" },
  { key: "TIMER_DIGITAL", label: "Timer", icon: Timer, color: "#EC4899" },
  { key: "REGULADOR_TENSION", label: "Reg.", icon: Zap, color: "#14B8A6" },
  { key: "CABLE_COMUNICACION", label: "Cable", icon: Cable, color: "#6B7280" },
];

const PLANTAS = [
  { nombre: "Altamira Norte", fv: "FV-001", cobertura: "Alta", items: { SIM: 4, DONGLE: 2, SMARTLOGGER: 1, ROUTER: 2, ANTENA: 3, TIMER_DIGITAL: 0, REGULADOR_TENSION: 1, CABLE_COMUNICACION: 120 } },
  { nombre: "Central Sur", fv: "FV-002", cobertura: "Media", items: { SIM: 6, DONGLE: 1, SMARTLOGGER: 2, ROUTER: 1, ANTENA: 2, TIMER_DIGITAL: 2, REGULADOR_TENSION: 0, CABLE_COMUNICACION: 85 } },
  { nombre: "Parque Solar Lomas", fv: "FV-003", cobertura: "Alta", items: { SIM: 8, DONGLE: 3, SMARTLOGGER: 2, ROUTER: 3, ANTENA: 4, TIMER_DIGITAL: 1, REGULADOR_TENSION: 2, CABLE_COMUNICACION: 240 } },
  { nombre: "Estación Rivero", fv: "FV-004", cobertura: "Baja", items: { SIM: 2, DONGLE: 1, SMARTLOGGER: 1, ROUTER: 0, ANTENA: 1, TIMER_DIGITAL: 0, REGULADOR_TENSION: 1, CABLE_COMUNICACION: 30 } },
  { nombre: "Parque Vientos del Sur", fv: "FV-005", cobertura: "Alta", items: { SIM: 5, DONGLE: 2, SMARTLOGGER: 3, ROUTER: 2, ANTENA: 5, TIMER_DIGITAL: 2, REGULADOR_TENSION: 2, CABLE_COMUNICACION: 180 } },
];

const barData = PLANTAS.map((p) => ({
  name: p.fv,
  total: Object.values(p.items).reduce((a, b) => a + b, 0),
  cobertura: p.cobertura,
}));

const COB: Record<string, { dot: string; badge: string; text: string }> = {
  Alta: { dot: "#22C55E", badge: "bg-green-500/10 text-green-400 border border-green-500/20", text: "Alta" },
  Media: { dot: "#EAB308", badge: "bg-yellow-500/10 text-yellow-400 border border-yellow-500/20", text: "Media" },
  Baja: { dot: "#EF4444", badge: "bg-red-500/10 text-red-400 border border-red-500/20", text: "Baja" },
};

// Heatmap: normalize value per column (0→dim, high→bright)
function heatColor(val: number, max: number, color: string): string {
  if (val === 0) return "transparent";
  const opacity = 0.15 + (val / max) * 0.75;
  return color + Math.round(opacity * 255).toString(16).padStart(2, "0");
}

const maxPerTipo: Record<string, number> = {};
TIPOS.forEach((t) => {
  maxPerTipo[t.key] = Math.max(...PLANTAS.map((p) => p.items[t.key as keyof typeof p.items]));
});

export function DashboardTabla() {
  return (
    <div className="min-h-screen bg-[#0A0F1E] text-white font-mono p-6">
      {/* Top KPIs */}
      <div className="grid grid-cols-4 gap-3 mb-8">
        {[
          { label: "Plantas", value: PLANTAS.length, sub: "activas" },
          { label: "Equipos", value: PLANTAS.reduce((a, p) => a + Object.values(p.items).reduce((x, y) => x + y, 0), 0), sub: "instalados" },
          { label: "Cobertura Alta", value: PLANTAS.filter((p) => p.cobertura === "Alta").length, sub: "plantas" },
          { label: "Cable total", value: `${PLANTAS.reduce((a, p) => a + p.items.CABLE_COMUNICACION, 0)}m`, sub: "metros" },
        ].map((kpi) => (
          <div key={kpi.label} className="border border-gray-800 bg-[#0D1525] p-4">
            <div className="text-[10px] text-gray-500 uppercase tracking-widest mb-1">{kpi.label}</div>
            <div className="text-3xl font-bold text-white">{kpi.value}</div>
            <div className="text-[10px] text-gray-600 uppercase tracking-wider mt-0.5">{kpi.sub}</div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-[1fr_260px] gap-6">
        {/* Left — heatmap table */}
        <div>
          <div className="text-[10px] text-gray-500 uppercase tracking-widest mb-3">Equipos por Planta — Heatmap</div>
          <div className="border border-gray-800 overflow-hidden">
            {/* Header */}
            <div className="grid border-b border-gray-800 bg-[#0D1525]" style={{ gridTemplateColumns: "200px repeat(8, 1fr)" }}>
              <div className="px-3 py-2 text-[9px] text-gray-600 uppercase tracking-widest">Planta</div>
              {TIPOS.map((t) => {
                const Icon = t.icon;
                return (
                  <div key={t.key} className="px-1 py-2 flex flex-col items-center gap-0.5 border-l border-gray-800">
                    <Icon size={10} style={{ color: t.color }} />
                    <span className="text-[8px] text-gray-600 uppercase">{t.label}</span>
                  </div>
                );
              })}
            </div>

            {/* Rows */}
            {PLANTAS.map((planta, ri) => {
              const cob = COB[planta.cobertura];
              return (
                <div
                  key={planta.nombre}
                  className={`grid border-b last:border-b-0 border-gray-800 hover:bg-white/[0.02] transition-colors`}
                  style={{ gridTemplateColumns: "200px repeat(8, 1fr)" }}
                >
                  <div className="px-3 py-3 flex flex-col justify-center">
                    <div className="text-xs font-bold text-white truncate">{planta.nombre}</div>
                    <div className="flex items-center gap-1.5 mt-0.5">
                      <span className="text-[9px] text-gray-600">{planta.fv}</span>
                      <span
                        className={`text-[8px] px-1.5 py-0.5 rounded-none font-bold uppercase tracking-widest ${cob.badge}`}
                      >
                        {cob.text}
                      </span>
                    </div>
                  </div>
                  {TIPOS.map((tipo) => {
                    const val = planta.items[tipo.key as keyof typeof planta.items];
                    const bg = heatColor(val, maxPerTipo[tipo.key], tipo.color);
                    return (
                      <div
                        key={tipo.key}
                        className="border-l border-gray-800 flex items-center justify-center py-3"
                        style={{ backgroundColor: bg }}
                      >
                        <span
                          className="text-xs font-bold"
                          style={{ color: val > 0 ? tipo.color : "#374151" }}
                        >
                          {val === 0 ? "—" : tipo.key === "CABLE_COMUNICACION" ? `${val}m` : val}
                        </span>
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>

        {/* Right — bar chart */}
        <div className="flex flex-col gap-4">
          <div className="border border-gray-800 bg-[#0D1525] p-4">
            <div className="text-[10px] text-gray-500 uppercase tracking-widest mb-4">Total por Planta</div>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={barData} layout="vertical" margin={{ left: 0, right: 8 }}>
                <XAxis type="number" tick={{ fontSize: 9, fill: "#4B5563" }} axisLine={false} tickLine={false} />
                <YAxis type="category" dataKey="name" tick={{ fontSize: 10, fill: "#9CA3AF", fontFamily: "monospace" }} axisLine={false} tickLine={false} width={40} />
                <Tooltip
                  contentStyle={{ background: "#0D1525", border: "1px solid #1F2937", borderRadius: 0, fontSize: 11, fontFamily: "monospace" }}
                  itemStyle={{ color: "#E5E7EB" }}
                  cursor={{ fill: "rgba(255,255,255,0.03)" }}
                />
                <Bar dataKey="total" radius={0} maxBarSize={16}>
                  {barData.map((entry) => (
                    <Cell key={entry.name} fill={COB[entry.cobertura].dot} fillOpacity={0.8} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* Tipo legend */}
          <div className="border border-gray-800 bg-[#0D1525] p-4">
            <div className="text-[10px] text-gray-500 uppercase tracking-widest mb-3">Tipos de equipo</div>
            {TIPOS.map((t) => {
              const Icon = t.icon;
              const total = PLANTAS.reduce((sum, p) => sum + p.items[t.key as keyof typeof p.items], 0);
              return (
                <div key={t.key} className="flex items-center justify-between mb-2 last:mb-0">
                  <div className="flex items-center gap-1.5">
                    <Icon size={10} style={{ color: t.color }} />
                    <span className="text-[10px] text-gray-400">{t.label}</span>
                  </div>
                  <span className="text-[10px] font-bold" style={{ color: t.color }}>
                    {t.key === "CABLE_COMUNICACION" ? `${total}m` : total}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
