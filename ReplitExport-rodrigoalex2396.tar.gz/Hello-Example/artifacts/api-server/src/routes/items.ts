import { Router, type IRouter } from "express";
import { eq, desc } from "drizzle-orm";
import { db, itemsTable, inventoryMovementsTable } from "@workspace/db";
import {
  CreateItemBody,
  UpdateItemBody,
  GetItemParams,
  UpdateItemParams,
  DeleteItemParams,
  ListItemsResponse,
  GetItemResponse,
  UpdateItemResponse,
  GetItemStatsResponse,
  CreateMovementBody,
  ListMovementsResponse,
  GetStockResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

const MATERIAL_TYPES = ["SIM", "DONGLE", "SMARTLOGGER", "ROUTER", "ANTENA", "TIMER_DIGITAL", "REGULADOR_TENSION", "CABLE_COMUNICACION"] as const;

// ── Items ──────────────────────────────────────────────────────────────────

router.get("/items/stats", async (req, res): Promise<void> => {
  const items = await db.select().from(itemsTable);
  const counts: Record<string, number> = {};
  for (const item of items) {
    counts[item.tipoMaterial] = (counts[item.tipoMaterial] ?? 0) + 1;
  }
  const stats = {
    total: items.length,
    byTipoMaterial: Object.entries(counts).map(([label, count]) => ({ label, count })),
  };
  res.json(GetItemStatsResponse.parse(stats));
});

router.get("/items", async (req, res): Promise<void> => {
  const items = await db.select().from(itemsTable).orderBy(desc(itemsTable.createdAt));
  res.json(ListItemsResponse.parse(items));
});

router.post("/items", async (req, res): Promise<void> => {
  const parsed = CreateItemBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [item] = await db.insert(itemsTable).values(parsed.data).returning();

  // Auto-decrement stock: register a SALIDA movement (uses cantidad — meters for cable, 1 unit for others)
  const cantidad = parsed.data.cantidad ?? 1;
  const seriePart = parsed.data.numeroSerie ? ` (N/S: ${parsed.data.numeroSerie})` : "";
  const unidad = parsed.data.tipoMaterial === "CABLE_COMUNICACION" ? `${cantidad}m` : `${cantidad}u`;
  await db.insert(inventoryMovementsTable).values({
    tipoMaterial: parsed.data.tipoMaterial,
    cantidad,
    tipoMovimiento: "SALIDA",
    notas: `Instalado en: ${parsed.data.nombrePlanta}${seriePart} [${unidad}]`,
  });

  res.status(201).json(GetItemResponse.parse(item));
});

router.get("/items/:id", async (req, res): Promise<void> => {
  const params = GetItemParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [item] = await db.select().from(itemsTable).where(eq(itemsTable.id, params.data.id));
  if (!item) {
    res.status(404).json({ error: "Equipo no encontrado" });
    return;
  }
  res.json(GetItemResponse.parse(item));
});

router.patch("/items/:id", async (req, res): Promise<void> => {
  const params = UpdateItemParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = UpdateItemBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [item] = await db
    .update(itemsTable)
    .set({ ...parsed.data, updatedAt: new Date() })
    .where(eq(itemsTable.id, params.data.id))
    .returning();
  if (!item) {
    res.status(404).json({ error: "Equipo no encontrado" });
    return;
  }
  res.json(UpdateItemResponse.parse(item));
});

router.delete("/items/:id", async (req, res): Promise<void> => {
  const params = DeleteItemParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [item] = await db.delete(itemsTable).where(eq(itemsTable.id, params.data.id)).returning();
  if (!item) {
    res.status(404).json({ error: "Equipo no encontrado" });
    return;
  }
  res.sendStatus(204);
});

// ── Inventory ──────────────────────────────────────────────────────────────

router.get("/inventory/stock", async (req, res): Promise<void> => {
  const movements = await db.select().from(inventoryMovementsTable);
  const stockMap: Record<string, number> = {
    SIM: 0,
    DONGLE: 0,
    SMARTLOGGER: 0,
  };
  for (const m of movements) {
    if (!(m.tipoMaterial in stockMap)) stockMap[m.tipoMaterial] = 0;
    if (m.tipoMovimiento === "ENTRADA") {
      stockMap[m.tipoMaterial] += m.cantidad;
    } else {
      stockMap[m.tipoMaterial] -= m.cantidad;
    }
  }
  const stock = Object.entries(stockMap).map(([tipoMaterial, stock]) => ({
    tipoMaterial,
    stock: Math.max(0, stock),
  }));
  res.json(GetStockResponse.parse(stock));
});

router.get("/inventory/movements", async (req, res): Promise<void> => {
  const movements = await db
    .select()
    .from(inventoryMovementsTable)
    .orderBy(desc(inventoryMovementsTable.createdAt));
  res.json(ListMovementsResponse.parse(movements));
});

router.post("/inventory/movements", async (req, res): Promise<void> => {
  const parsed = CreateMovementBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const [movement] = await db
    .insert(inventoryMovementsTable)
    .values(parsed.data)
    .returning();
  res.status(201).json(movement);
});

router.delete("/inventory/movements/:id", async (req, res): Promise<void> => {
  const id = parseInt(req.params.id, 10);
  if (isNaN(id)) {
    res.status(400).json({ error: "ID inválido" });
    return;
  }
  const [deleted] = await db
    .delete(inventoryMovementsTable)
    .where(eq(inventoryMovementsTable.id, id))
    .returning();
  if (!deleted) {
    res.status(404).json({ error: "Movimiento no encontrado" });
    return;
  }
  res.sendStatus(204);
});

export default router;
