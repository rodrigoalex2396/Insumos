import { Router, type IRouter } from "express";
import { eq, sql } from "drizzle-orm";
import { db, chipsTable } from "@workspace/db";
import {
  CreateChipBody,
  UpdateChipBody,
  GetChipParams,
  UpdateChipParams,
  DeleteChipParams,
  ListChipsResponse,
  GetChipResponse,
  UpdateChipResponse,
  GetChipStatsResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

router.get("/chips/stats", async (req, res): Promise<void> => {
  const chips = await db.select().from(chipsTable);
  const total = chips.length;

  const groupBy = (field: keyof typeof chips[0]) => {
    const counts: Record<string, number> = {};
    for (const chip of chips) {
      const key = String(chip[field] ?? "Unknown");
      counts[key] = (counts[key] ?? 0) + 1;
    }
    return Object.entries(counts).map(([label, count]) => ({ label, count }));
  };

  const stats = {
    total,
    byFv: groupBy("fv"),
    byTipoSim: groupBy("tipoSim"),
    byCobertura: groupBy("cobertura"),
  };

  res.json(GetChipStatsResponse.parse(stats));
});

router.get("/chips", async (req, res): Promise<void> => {
  const chips = await db.select().from(chipsTable).orderBy(chipsTable.createdAt);
  res.json(ListChipsResponse.parse(chips));
});

router.post("/chips", async (req, res): Promise<void> => {
  const parsed = CreateChipBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [chip] = await db.insert(chipsTable).values(parsed.data).returning();
  res.status(201).json(GetChipResponse.parse(chip));
});

router.get("/chips/:id", async (req, res): Promise<void> => {
  const params = GetChipParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [chip] = await db
    .select()
    .from(chipsTable)
    .where(eq(chipsTable.id, params.data.id));

  if (!chip) {
    res.status(404).json({ error: "Chip no encontrado" });
    return;
  }

  res.json(GetChipResponse.parse(chip));
});

router.patch("/chips/:id", async (req, res): Promise<void> => {
  const params = UpdateChipParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const parsed = UpdateChipBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const [chip] = await db
    .update(chipsTable)
    .set({ ...parsed.data, updatedAt: new Date() })
    .where(eq(chipsTable.id, params.data.id))
    .returning();

  if (!chip) {
    res.status(404).json({ error: "Chip no encontrado" });
    return;
  }

  res.json(UpdateChipResponse.parse(chip));
});

router.delete("/chips/:id", async (req, res): Promise<void> => {
  const params = DeleteChipParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const [chip] = await db
    .delete(chipsTable)
    .where(eq(chipsTable.id, params.data.id))
    .returning();

  if (!chip) {
    res.status(404).json({ error: "Chip no encontrado" });
    return;
  }

  res.sendStatus(204);
});

export default router;
