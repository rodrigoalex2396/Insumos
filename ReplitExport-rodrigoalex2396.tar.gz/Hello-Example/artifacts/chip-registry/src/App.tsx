import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";

import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import ItemsList from "@/pages/items-list";
import ItemForm from "@/pages/item-form";
import ItemDetail from "@/pages/item-detail";
import InventoryList from "@/pages/inventory-list";
import MovementForm from "@/pages/movement-form";
import Plantas from "@/pages/plantas";
import { Layout } from "@/components/layout";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/items" component={ItemsList} />
        <Route path="/items/new" component={ItemForm} />
        <Route path="/items/:id">
          {(params) => <ItemDetail id={Number(params.id)} />}
        </Route>
        <Route path="/inventory" component={InventoryList} />
        <Route path="/inventory/new" component={MovementForm} />
        <Route path="/plantas" component={Plantas} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
