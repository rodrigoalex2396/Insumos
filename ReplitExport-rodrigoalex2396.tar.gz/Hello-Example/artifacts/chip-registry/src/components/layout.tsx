import { Link, useLocation } from "wouter";
import { Activity, Box, Database, Plus, LayoutDashboard, MapPin } from "lucide-react";
import { ReactNode } from "react";

const NAV_ITEMS = [
  { href: "/", label: "Dashboard", icon: LayoutDashboard },
  { href: "/items", label: "Equipos", icon: Database },
  { href: "/items/new", label: "Instalar", icon: Plus },
  { href: "/plantas", label: "Plantas", icon: MapPin },
  { href: "/inventory", label: "Stock", icon: Box },
];

export function Layout({ children }: { children: ReactNode }) {
  const [location] = useLocation();

  const isActive = (href: string) =>
    href === "/" ? location === "/" : location.startsWith(href);

  return (
    <div className="flex min-h-[100dvh] w-full bg-background text-foreground font-mono selection:bg-primary selection:text-primary-foreground">

      {/* ── Desktop sidebar ───────────────────────────────────── */}
      <aside className="w-64 border-r border-border flex-col hidden md:flex shrink-0 bg-background z-10">
        <div className="h-14 border-b border-border flex items-center px-4 shrink-0">
          <Link href="/" className="font-bold text-xl text-primary tracking-tighter uppercase flex items-center gap-2">
            <Activity className="w-5 h-5" />
            SOLARSTOCK
          </Link>
        </div>

        <div className="flex-1 overflow-y-auto py-4">
          <nav className="px-2 space-y-1">
            <p className="px-2 text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2 mt-4">Overview</p>
            <Link href="/" className={`flex items-center gap-3 px-3 py-2 text-sm font-medium border ${isActive("/") ? "bg-accent text-accent-foreground border-primary" : "border-transparent text-muted-foreground hover:bg-secondary/50 hover:text-foreground"}`}>
              <LayoutDashboard className="w-4 h-4" />
              DASHBOARD
            </Link>

            <p className="px-2 text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2 mt-6">Equipment</p>
            <Link href="/items" className={`flex items-center gap-3 px-3 py-2 text-sm font-medium border ${location === "/items" ? "bg-accent text-accent-foreground border-primary" : "border-transparent text-muted-foreground hover:bg-secondary/50 hover:text-foreground"}`}>
              <Database className="w-4 h-4" />
              REGISTRY
            </Link>
            <Link href="/items/new" className={`flex items-center gap-3 px-3 py-2 text-sm font-medium border ${location === "/items/new" ? "bg-accent text-accent-foreground border-primary" : "border-transparent text-muted-foreground hover:bg-secondary/50 hover:text-foreground"}`}>
              <Plus className="w-4 h-4" />
              NEW INSTALL
            </Link>

            <Link href="/plantas" className={`flex items-center gap-3 px-3 py-2 text-sm font-medium border ${location === "/plantas" ? "bg-accent text-accent-foreground border-primary" : "border-transparent text-muted-foreground hover:bg-secondary/50 hover:text-foreground"}`}>
              <MapPin className="w-4 h-4" />
              PLANTAS
            </Link>

            <p className="px-2 text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2 mt-6">Supply</p>
            <Link href="/inventory" className={`flex items-center gap-3 px-3 py-2 text-sm font-medium border ${location === "/inventory" ? "bg-accent text-accent-foreground border-primary" : "border-transparent text-muted-foreground hover:bg-secondary/50 hover:text-foreground"}`}>
              <Box className="w-4 h-4" />
              STOCK LEVELS
            </Link>
            <Link href="/inventory/new" className={`flex items-center gap-3 px-3 py-2 text-sm font-medium border ${location === "/inventory/new" ? "bg-accent text-accent-foreground border-primary" : "border-transparent text-muted-foreground hover:bg-secondary/50 hover:text-foreground"}`}>
              <Plus className="w-4 h-4" />
              RECEIVE STOCK
            </Link>
          </nav>
        </div>

        <div className="p-4 border-t border-border bg-secondary/20">
          <div className="text-xs text-muted-foreground font-mono">
            OP-MODE: ACTIVE<br />
            SYS: ONLINE
          </div>
        </div>
      </aside>

      {/* ── Main content ──────────────────────────────────────── */}
      <main className="flex-1 flex flex-col min-w-0 bg-background">
        {/* Mobile top bar */}
        <header className="h-14 border-b border-border flex items-center px-4 justify-between shrink-0 bg-background md:hidden sticky top-0 z-20">
          <Link href="/" className="font-bold text-lg text-primary tracking-tighter uppercase flex items-center gap-2">
            <Activity className="w-5 h-5" />
            SOLARSTOCK
          </Link>
        </header>

        {/* Page content — adds bottom padding on mobile so content isn't hidden behind nav */}
        <div className="flex-1 overflow-y-auto pb-20 md:pb-0">
          {children}
        </div>
      </main>

      {/* ── Mobile bottom navigation ──────────────────────────── */}
      <nav className="fixed bottom-0 left-0 right-0 z-30 md:hidden bg-background border-t border-border grid grid-cols-5">
        {NAV_ITEMS.map(({ href, label, icon: Icon }) => {
          const active = isActive(href);
          return (
            <Link
              key={href}
              href={href}
              className={`flex flex-col items-center justify-center gap-1 py-3 text-[10px] font-bold uppercase tracking-widest transition-colors
                ${active ? "text-primary border-t-2 border-primary -mt-px" : "text-muted-foreground hover:text-foreground"}`}
            >
              <Icon className="w-5 h-5" />
              {label}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
