import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useGetItem, useUpdateItem, useDeleteItem } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Trash2, Save, X } from "lucide-react";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { format } from "date-fns";

const ALL_TYPES = ["SIM", "DONGLE", "SMARTLOGGER", "ROUTER", "ANTENA", "TIMER_DIGITAL", "REGULADOR_TENSION", "CABLE_COMUNICACION"] as const;
const TYPE_LABELS: Record<string, string> = {
  SIM: "SIM", DONGLE: "Dongle", SMARTLOGGER: "SmartLogger",
  ROUTER: "Router", ANTENA: "Antena", TIMER_DIGITAL: "Timer Digital",
  REGULADOR_TENSION: "Regulador de Tensión", CABLE_COMUNICACION: "Cable Comunicación",
};

export default function ItemDetail({ id }: { id: number }) {
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const { data: item, isLoading } = useGetItem(id, { query: { enabled: !!id, queryKey: [] } });
  const updateItem = useUpdateItem();
  const deleteItem = useDeleteItem();

  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    nombrePlanta: "",
    tipoMaterial: "SIM" as typeof ALL_TYPES[number],
    numeroSerie: "",
    cantidad: 1,
    compania: "",
    notas: "",
  });

  useEffect(() => {
    if (item) {
      setFormData({
        nombrePlanta: item.nombrePlanta,
        tipoMaterial: item.tipoMaterial as typeof ALL_TYPES[number],
        numeroSerie: item.numeroSerie || "",
        cantidad: item.cantidad,
        compania: item.compania || "",
        notas: item.notas || "",
      });
    }
  }, [item]);

  if (isLoading) return <div className="p-8 text-center text-muted-foreground uppercase tracking-widest animate-pulse">Cargando...</div>;
  if (!item) return <div className="p-8 text-center text-destructive uppercase tracking-widest">Registro no encontrado</div>;

  const isCable = formData.tipoMaterial === "CABLE_COMUNICACION";

  const handleSave = () => {
    updateItem.mutate({
      id,
      data: {
        ...formData,
        numeroSerie: formData.numeroSerie || null,
        compania: formData.tipoMaterial === "SIM" ? formData.compania || null : null,
      }
    }, {
      onSuccess: () => { toast({ title: "ACTUALIZADO" }); setIsEditing(false); },
      onError: () => toast({ variant: "destructive", title: "ERROR", description: "No se pudo actualizar." }),
    });
  };

  const handleDelete = () => {
    deleteItem.mutate({ id }, {
      onSuccess: () => { toast({ title: "ELIMINADO" }); navigate("/items"); },
      onError: () => toast({ variant: "destructive", title: "ERROR" }),
    });
  };

  const Field = ({ label, children }: { label: string; children: React.ReactNode }) => (
    <div className="p-4 space-y-1.5">
      <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">{label}</p>
      {children}
    </div>
  );

  return (
    <div className="p-4 md:p-8 max-w-3xl mx-auto space-y-5 pb-24 md:pb-8">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <Button variant="outline" size="icon" onClick={() => navigate("/items")} className="rounded-none border-border shrink-0">
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div>
            <h1 className="text-xl md:text-2xl font-bold tracking-tighter uppercase">{isEditing ? "Editar Registro" : "Detalle"}</h1>
            <p className="text-muted-foreground text-xs font-mono">ID: {item.id}</p>
          </div>
        </div>

        <div className="flex gap-2">
          {isEditing ? (
            <>
              <Button variant="outline" size="sm" onClick={() => setIsEditing(false)} className="rounded-none font-bold uppercase tracking-wider">
                <X className="w-3.5 h-3.5 mr-1" /> Cancelar
              </Button>
              <Button size="sm" onClick={handleSave} disabled={updateItem.isPending} className="rounded-none font-bold uppercase tracking-wider">
                <Save className="w-3.5 h-3.5 mr-1" /> Guardar
              </Button>
            </>
          ) : (
            <>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="destructive" size="sm" className="rounded-none font-bold">
                    <Trash2 className="w-3.5 h-3.5" />
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent className="rounded-none border-border bg-background font-mono">
                  <AlertDialogHeader>
                    <AlertDialogTitle className="uppercase">¿Eliminar registro?</AlertDialogTitle>
                    <AlertDialogDescription>Esta acción no se puede deshacer.</AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel className="rounded-none font-bold uppercase">Cancelar</AlertDialogCancel>
                    <AlertDialogAction onClick={handleDelete} className="bg-destructive text-destructive-foreground rounded-none font-bold uppercase hover:bg-destructive/90">Eliminar</AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
              <Button size="sm" onClick={() => setIsEditing(true)} className="rounded-none font-bold uppercase tracking-wider">
                Editar
              </Button>
            </>
          )}
        </div>
      </div>

      <Card className="border-border bg-card rounded-none">
        <CardContent className="p-0 divide-y divide-border">
          <div className="grid grid-cols-1 sm:grid-cols-2 divide-y sm:divide-y-0 sm:divide-x divide-border">
            <Field label="Planta">
              {isEditing
                ? <Input value={formData.nombrePlanta} onChange={e => setFormData({ ...formData, nombrePlanta: e.target.value })} className="rounded-none border-border font-bold uppercase" />
                : <p className="text-lg font-bold uppercase">{item.nombrePlanta}</p>}
            </Field>
            <Field label="Tipo de Material">
              {isEditing ? (
                <Select value={formData.tipoMaterial} onValueChange={val => setFormData({ ...formData, tipoMaterial: val as typeof ALL_TYPES[number] })}>
                  <SelectTrigger className="rounded-none border-border font-bold uppercase"><SelectValue /></SelectTrigger>
                  <SelectContent className="rounded-none border-border">
                    {ALL_TYPES.map(t => <SelectItem key={t} value={t} className="uppercase font-mono">{TYPE_LABELS[t]}</SelectItem>)}
                  </SelectContent>
                </Select>
              ) : (
                <span className="inline-block px-2 py-1 border text-sm font-bold border-primary text-primary bg-primary/10">
                  {TYPE_LABELS[item.tipoMaterial] || item.tipoMaterial}
                </span>
              )}
            </Field>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 divide-y sm:divide-y-0 sm:divide-x divide-border">
            <Field label={isCable ? "Metros Usados" : "Número de Serie"}>
              {isEditing
                ? <Input value={formData.numeroSerie} onChange={e => setFormData({ ...formData, numeroSerie: e.target.value })} className="rounded-none border-border font-mono uppercase" />
                : <p className="font-mono text-muted-foreground">{item.numeroSerie || "-"}</p>}
            </Field>
            <Field label={isCable ? "Cantidad (m)" : "Cantidad (u)"}>
              {isEditing
                ? <Input type="number" min="1" value={formData.cantidad} onChange={e => setFormData({ ...formData, cantidad: Number(e.target.value) })} className="rounded-none border-border font-mono" />
                : <p className="font-bold font-mono text-lg">{item.cantidad}{isCable ? " m" : " u"}</p>}
            </Field>
          </div>

          {(formData.tipoMaterial === "SIM" || item.tipoMaterial === "SIM") && (
            <Field label="Compañía">
              {isEditing
                ? <Input value={formData.compania} onChange={e => setFormData({ ...formData, compania: e.target.value })} className="rounded-none border-border font-bold uppercase" />
                : <p className="font-bold uppercase">{item.compania || "-"}</p>}
            </Field>
          )}

          <Field label="Notas">
            {isEditing
              ? <Textarea value={formData.notas} onChange={e => setFormData({ ...formData, notas: e.target.value })} className="rounded-none border-border min-h-[80px]" />
              : <p className="text-sm text-foreground whitespace-pre-wrap">{item.notas || "-"}</p>}
          </Field>

          <div className="p-4 bg-secondary/30 flex flex-wrap justify-between gap-2 text-xs font-mono text-muted-foreground uppercase">
            <span>Registrado: {format(new Date(item.createdAt), "dd/MM/yyyy HH:mm")}</span>
            {item.updatedAt && <span>Actualizado: {format(new Date(item.updatedAt), "dd/MM/yyyy HH:mm")}</span>}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
