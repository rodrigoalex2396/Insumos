import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useCreateMovement } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Save, ArrowDownRight, ArrowUpRight } from "lucide-react";
import { format } from "date-fns";

const formSchema = z.object({
  tipoMaterial: z.enum(["SIM", "DONGLE", "SMARTLOGGER", "ROUTER", "ANTENA", "TIMER_DIGITAL", "REGULADOR_TENSION", "CABLE_COMUNICACION"]),
  cantidad: z.coerce.number().min(1, "Mínimo 1 unidad"),
  tipoMovimiento: z.enum(["ENTRADA", "SALIDA"]),
  fecha: z.string().min(1, "La fecha es requerida"),
  notas: z.string().optional(),
});

type FormValues = z.infer<typeof formSchema>;

export default function MovementForm() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const createMovement = useCreateMovement();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      tipoMaterial: "SIM",
      cantidad: 1,
      tipoMovimiento: "ENTRADA",
      fecha: format(new Date(), "yyyy-MM-dd'T'HH:mm"),
      notas: "",
    },
  });

  const tipoMovimiento = form.watch("tipoMovimiento");

  const onSubmit = (data: FormValues) => {
    createMovement.mutate({
      data: {
        ...data,
        fecha: new Date(data.fecha).toISOString(),
      }
    }, {
      onSuccess: () => {
        toast({ title: "REGISTRADO", description: "Movimiento de stock guardado." });
        navigate("/inventory");
      },
      onError: () => {
        toast({ variant: "destructive", title: "ERROR", description: "No se pudo registrar el movimiento." });
      }
    });
  };

  return (
    <div className="p-4 md:p-8 max-w-3xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" onClick={() => navigate('/inventory')} className="rounded-none border-border shrink-0">
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold tracking-tighter uppercase mb-1">
            {tipoMovimiento === "ENTRADA" ? "Recibir Stock" : "Registrar Salida"}
          </h1>
          <p className="text-muted-foreground uppercase text-sm tracking-widest">
            {tipoMovimiento === "ENTRADA" ? "Ingreso de material desde oficina" : "Salida manual de stock"}
          </p>
        </div>
      </div>

      <Card className="border-border bg-card rounded-none">
        <CardContent className="p-6">
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">

              {/* Tipo de movimiento */}
              <FormField
                control={form.control}
                name="tipoMovimiento"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="uppercase text-xs font-bold tracking-widest text-muted-foreground">Tipo de Movimiento</FormLabel>
                    <div className="grid grid-cols-2 gap-3">
                      {(["ENTRADA", "SALIDA"] as const).map(tipo => (
                        <button
                          key={tipo}
                          type="button"
                          onClick={() => field.onChange(tipo)}
                          className={`flex items-center gap-3 p-4 border-2 transition-colors font-bold uppercase tracking-widest text-sm ${
                            field.value === tipo
                              ? tipo === "ENTRADA"
                                ? "border-emerald-500 bg-emerald-500/10 text-emerald-500"
                                : "border-destructive bg-destructive/10 text-destructive"
                              : "border-border text-muted-foreground hover:bg-secondary/50"
                          }`}
                        >
                          {tipo === "ENTRADA"
                            ? <ArrowDownRight className="w-5 h-5 shrink-0" />
                            : <ArrowUpRight className="w-5 h-5 shrink-0" />
                          }
                          {tipo === "ENTRADA" ? "Entrada" : "Salida"}
                        </button>
                      ))}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Material */}
                <FormField
                  control={form.control}
                  name="tipoMaterial"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="uppercase text-xs font-bold tracking-widest text-muted-foreground">Tipo de Material</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger className="rounded-none border-border h-12 uppercase font-bold">
                            <SelectValue placeholder="Seleccionar material" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="rounded-none border-border">
                          <SelectItem value="SIM">SIM</SelectItem>
                          <SelectItem value="DONGLE">Dongle</SelectItem>
                          <SelectItem value="SMARTLOGGER">SmartLogger</SelectItem>
                          <SelectItem value="ROUTER">Router</SelectItem>
                          <SelectItem value="ANTENA">Antena</SelectItem>
                          <SelectItem value="TIMER_DIGITAL">Timer Digital</SelectItem>
                          <SelectItem value="REGULADOR_TENSION">Regulador de Tensión</SelectItem>
                          <SelectItem value="CABLE_COMUNICACION">Cable Comunicación (m)</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Cantidad */}
                <FormField
                  control={form.control}
                  name="cantidad"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel className="uppercase text-xs font-bold tracking-widest text-muted-foreground">Cantidad</FormLabel>
                      <FormControl>
                        <Input type="number" min="1" {...field} className="rounded-none border-border h-12 font-mono text-lg" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              {/* Fecha */}
              <FormField
                control={form.control}
                name="fecha"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="uppercase text-xs font-bold tracking-widest text-muted-foreground">Fecha del Movimiento</FormLabel>
                    <FormControl>
                      <Input
                        type="datetime-local"
                        {...field}
                        className="rounded-none border-border h-12 font-mono"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Notas */}
              <FormField
                control={form.control}
                name="notas"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel className="uppercase text-xs font-bold tracking-widest text-muted-foreground">Referencia / Albarán</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder="Número de albarán, ticket, referencia..."
                        {...field}
                        className="rounded-none border-border min-h-[80px] resize-y"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="flex justify-end pt-4 border-t border-border">
                <Button
                  type="submit"
                  disabled={createMovement.isPending}
                  className={`rounded-none h-12 px-8 font-bold uppercase tracking-widest ${
                    tipoMovimiento === "SALIDA"
                      ? "bg-destructive text-destructive-foreground hover:bg-destructive/90"
                      : ""
                  }`}
                >
                  {createMovement.isPending ? "PROCESANDO..." : (
                    <>
                      <Save className="w-4 h-4 mr-2" />
                      {tipoMovimiento === "ENTRADA" ? "Confirmar Entrada" : "Confirmar Salida"}
                    </>
                  )}
                </Button>
              </div>

            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
