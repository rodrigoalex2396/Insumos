import { Link, useLocation } from "wouter";
import { useListMovements, useGetStock, useDeleteMovement } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { format } from "date-fns";
import * as XLSX from "xlsx";
import { Box, Download, Plus, ArrowDownRight, ArrowUpRight, Trash2 } from "lucide-react";
import { useQueryClient } from "@tanstack/react-query";

export default function InventoryList() {
  const { data: movements, isLoading: loadingMovements } = useListMovements();
  const { data: stock, isLoading: loadingStock } = useGetStock();
  const deleteMovement = useDeleteMovement();
  const queryClient = useQueryClient();
  const [, navigate] = useLocation();

  const handleDelete = (id: number) => {
    deleteMovement.mutate({ id }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ["/api/inventory/movements"] });
        queryClient.invalidateQueries({ queryKey: ["/api/inventory/stock"] });
      },
    });
  };

  const sortedMovements = movements ? [...movements].sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime()) : [];

  const exportExcel = () => {
    if (!movements?.length || !stock) return;
    const wb = XLSX.utils.book_new();

    // Sheet 1: Stock Summary
    const wsStock = XLSX.utils.json_to_sheet(stock.map(s => ({
      Material: s.tipoMaterial,
      'Stock Actual': s.stock
    })));
    XLSX.utils.book_append_sheet(wb, wsStock, "Resumen Stock");

    // Sheet 2: Movement History
    const wsMov = XLSX.utils.json_to_sheet(sortedMovements.map(m => ({
      ID: m.id,
      Fecha: format(new Date(m.fecha), 'yyyy-MM-dd HH:mm:ss'),
      Material: m.tipoMaterial,
      Tipo: m.tipoMovimiento,
      Cantidad: m.cantidad,
      Notas: m.notas || '-'
    })));
    XLSX.utils.book_append_sheet(wb, wsMov, "Historial Movimientos");

    XLSX.writeFile(wb, `solarstock-inventory-${format(new Date(), 'yyyyMMdd-HHmm')}.xlsx`);
  };

  const stockMap = stock?.reduce((acc, curr) => {
    acc[curr.tipoMaterial] = curr.stock;
    return acc;
  }, {} as Record<string, number>) || {};

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tighter uppercase mb-1 flex items-center gap-2">
            <Box className="w-6 h-6 text-primary" />
            Inventory & Supply
          </h1>
          <p className="text-muted-foreground uppercase text-sm tracking-widest">Manage field stock levels</p>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" onClick={exportExcel} disabled={!movements?.length || loadingMovements} className="border-border rounded-none font-bold uppercase tracking-wider">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button onClick={() => navigate('/inventory/new')} className="rounded-none font-bold uppercase tracking-wider">
            <Plus className="w-4 h-4 mr-2" />
            Receive Stock
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {['SIM', 'DONGLE', 'SMARTLOGGER'].map(type => (
          <Card key={type} className="border-border bg-card rounded-none">
            <CardContent className="p-6 flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">{type} STOCK</p>
                <p className="text-4xl font-bold mt-2">{loadingStock ? '-' : stockMap[type] || 0}</p>
              </div>
              <div className="h-12 w-12 border-2 border-primary/20 flex items-center justify-center bg-primary/5 text-primary">
                <Box className="w-6 h-6" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card className="border-border bg-card rounded-none">
        <CardHeader className="border-b border-border bg-secondary/30 pb-4">
          <CardTitle className="text-sm font-bold uppercase tracking-widest">Movement History</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm whitespace-nowrap">
              <thead>
                <tr className="border-b border-border bg-secondary/50 uppercase tracking-widest text-muted-foreground">
                  <th className="text-left p-3 font-bold text-xs">Fecha</th>
                  <th className="text-left p-3 font-bold text-xs">Tipo</th>
                  <th className="text-left p-3 font-bold text-xs">Material</th>
                  <th className="text-left p-3 font-bold text-xs">Cant.</th>
                  <th className="text-left p-3 font-bold text-xs hidden sm:table-cell">Notas</th>
                  <th className="p-3"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {loadingMovements ? (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-muted-foreground uppercase tracking-widest animate-pulse">
                      Cargando...
                    </td>
                  </tr>
                ) : sortedMovements.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="p-8 text-center text-muted-foreground uppercase tracking-widest">
                      Sin movimientos
                    </td>
                  </tr>
                ) : (
                  sortedMovements.map(mov => (
                    <tr key={mov.id} className="hover:bg-secondary/20 transition-colors">
                      <td className="p-3 text-muted-foreground font-mono text-xs">{format(new Date(mov.fecha), 'dd/MM/yy HH:mm')}</td>
                      <td className="p-3">
                        <span className={`inline-flex items-center gap-1 px-2 py-1 border text-xs font-bold ${
                          mov.tipoMovimiento === 'ENTRADA' ? 'border-emerald-500 text-emerald-500 bg-emerald-500/10' : 'border-destructive text-destructive bg-destructive/10'
                        }`}>
                          {mov.tipoMovimiento === 'ENTRADA' ? <ArrowDownRight className="w-3 h-3" /> : <ArrowUpRight className="w-3 h-3" />}
                          {mov.tipoMovimiento === 'ENTRADA' ? 'ENT' : 'SAL'}
                        </span>
                      </td>
                      <td className="p-3 font-bold text-sm">{mov.tipoMaterial}</td>
                      <td className="p-3 font-mono font-bold">{mov.tipoMovimiento === 'ENTRADA' ? '+' : '-'}{mov.cantidad}</td>
                      <td className="p-3 text-muted-foreground text-sm hidden sm:table-cell max-w-[160px] truncate">{mov.notas || '-'}</td>
                      <td className="p-3">
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <button className="p-2 text-muted-foreground hover:text-destructive transition-colors rounded">
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </AlertDialogTrigger>
                          <AlertDialogContent className="rounded-none border-border bg-background font-mono">
                            <AlertDialogHeader>
                              <AlertDialogTitle className="uppercase tracking-wider">¿Eliminar movimiento?</AlertDialogTitle>
                              <AlertDialogDescription className="text-muted-foreground">
                                Se eliminará este registro de {mov.tipoMovimiento === 'ENTRADA' ? 'entrada' : 'salida'} de {mov.cantidad} {mov.tipoMaterial}. El stock se recalculará automáticamente.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel className="rounded-none font-bold uppercase tracking-wider">Cancelar</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => handleDelete(mov.id)}
                                className="rounded-none bg-destructive text-destructive-foreground font-bold uppercase tracking-wider hover:bg-destructive/90"
                              >
                                Eliminar
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
