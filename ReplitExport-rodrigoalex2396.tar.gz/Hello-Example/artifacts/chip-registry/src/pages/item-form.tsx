import { useLocation } from "wouter";
import { useForm, useFieldArray, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useCreateItem } from "@workspace/api-client-react";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { ArrowLeft, Save, Plus, Trash2, Cable } from "lucide-react";

const ALL_TYPES = ["SIM", "DONGLE", "SMARTLOGGER", "ROUTER", "ANTENA", "TIMER_DIGITAL", "REGULADOR_TENSION", "CABLE_COMUNICACION"] as const;
const TYPE_LABELS: Record<string, string> = {
  SIM: "SIM",
  DONGLE: "Dongle",
  SMARTLOGGER: "SmartLogger",
  ROUTER: "Router",
  ANTENA: "Antena",
  TIMER_DIGITAL: "Timer Digital",
  REGULADOR_TENSION: "Regulador de Tensión",
  CABLE_COMUNICACION: "Cable Comunicación",
};

const rowSchema = z.object({
  tipoMaterial: z.enum(ALL_TYPES),
  numeroSerie: z.string().optional(),
  cantidad: z.coerce.number().min(1, "Mínimo 1"),
  compania: z.string().optional(),
});

const formSchema = z.object({
  nombrePlanta: z.string().min(1, "Nombre de planta requerido"),
  notas: z.string().optional(),
  items: z.array(rowSchema).min(1),
});

type FormValues = z.infer<typeof formSchema>;

export default function ItemForm() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const createItem = useCreateItem();

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      nombrePlanta: "",
      notas: "",
      items: [{ tipoMaterial: "SIM", numeroSerie: "", cantidad: 1, compania: "" }],
    },
  });

  const { fields, append, remove } = useFieldArray({ control: form.control, name: "items" });

  const isSaving = createItem.isPending;

  const onSubmit = async (data: FormValues) => {
    try {
      for (const row of data.items) {
        await new Promise<void>((resolve, reject) => {
          createItem.mutate({
            data: {
              nombrePlanta: data.nombrePlanta,
              tipoMaterial: row.tipoMaterial,
              numeroSerie: row.numeroSerie || undefined,
              cantidad: row.cantidad,
              compania: row.tipoMaterial === "SIM" ? row.compania || undefined : undefined,
              notas: data.notas || undefined,
            }
          }, {
            onSuccess: () => resolve(),
            onError: (e) => reject(e),
          });
        });
      }
      toast({ title: "REGISTRADO", description: `${data.items.length} insumo(s) instalado(s) en ${data.nombrePlanta}.` });
      navigate("/items");
    } catch {
      toast({ variant: "destructive", title: "ERROR", description: "Fallo al registrar uno o más insumos." });
    }
  };

  return (
    <div className="p-4 md:p-6 max-w-3xl mx-auto space-y-5 pb-24 md:pb-8">
      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" onClick={() => navigate("/items")} className="rounded-none border-border shrink-0">
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-2xl md:text-3xl font-bold tracking-tighter uppercase mb-1">Nueva Instalación</h1>
          <p className="text-muted-foreground uppercase text-xs tracking-widest">Registrar equipos instalados en planta</p>
        </div>
      </div>

      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
        {/* Plant name */}
        <Card className="border-border bg-card rounded-none">
          <CardContent className="p-4 space-y-4">
            <div>
              <label className="uppercase text-xs font-bold tracking-widest text-muted-foreground block mb-1.5">Nombre de Planta</label>
              <Input
                placeholder="Ej: Altamira, Central Sur..."
                {...form.register("nombrePlanta")}
                className="rounded-none border-border h-12 uppercase font-bold"
              />
              {form.formState.errors.nombrePlanta && (
                <p className="text-destructive text-xs mt-1">{form.formState.errors.nombrePlanta.message}</p>
              )}
            </div>
            <div>
              <label className="uppercase text-xs font-bold tracking-widest text-muted-foreground block mb-1.5">Notas (opcional)</label>
              <Textarea
                placeholder="Observaciones de la instalación..."
                {...form.register("notas")}
                className="rounded-none border-border resize-none min-h-[60px]"
              />
            </div>
          </CardContent>
        </Card>

        {/* Equipment rows */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Insumos Instalados</p>
            <Button
              type="button"
              size="sm"
              variant="outline"
              onClick={() => append({ tipoMaterial: "SIM", numeroSerie: "", cantidad: 1, compania: "" })}
              className="rounded-none border-primary text-primary font-bold uppercase tracking-wider h-8 px-3 text-xs hover:bg-primary/10"
            >
              <Plus className="w-3.5 h-3.5 mr-1" />
              Agregar insumo
            </Button>
          </div>

          {fields.map((field, index) => (
            <EquipmentRow
              key={field.id}
              index={index}
              form={form}
              onRemove={fields.length > 1 ? () => remove(index) : undefined}
            />
          ))}
        </div>

        <div className="flex justify-end pt-2">
          <Button type="submit" disabled={isSaving} className="rounded-none h-12 px-8 font-bold uppercase tracking-widest w-full md:w-auto">
            {isSaving ? "GUARDANDO..." : (
              <>
                <Save className="w-4 h-4 mr-2" />
                Registrar {fields.length > 1 ? `(${fields.length} insumos)` : ""}
              </>
            )}
          </Button>
        </div>
      </form>
    </div>
  );
}

function EquipmentRow({
  index, form, onRemove
}: {
  index: number;
  form: ReturnType<typeof useForm<FormValues>>;
  onRemove?: () => void;
}) {
  const tipoMaterial = form.watch(`items.${index}.tipoMaterial`);
  const isCable = tipoMaterial === "CABLE_COMUNICACION";

  return (
    <Card className="border-border bg-card rounded-none">
      <CardContent className="p-4 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-muted-foreground uppercase tracking-widest">Insumo #{index + 1}</span>
          {onRemove && (
            <button type="button" onClick={onRemove} className="text-muted-foreground hover:text-destructive transition-colors p-1">
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>

        <div className="grid grid-cols-2 gap-3">
          {/* Tipo material */}
          <div className="col-span-2 sm:col-span-1">
            <label className="uppercase text-xs font-bold tracking-widest text-muted-foreground block mb-1.5">Tipo</label>
            <Controller
              control={form.control}
              name={`items.${index}.tipoMaterial`}
              render={({ field }) => (
                <Select value={field.value} onValueChange={field.onChange}>
                  <SelectTrigger className="rounded-none border-border h-11 font-bold uppercase">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="rounded-none border-border">
                    {ALL_TYPES.map(t => (
                      <SelectItem key={t} value={t} className="font-mono uppercase">{TYPE_LABELS[t]}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            />
          </div>

          {/* Cantidad (cable=metros, otros=unidades) */}
          <div className="col-span-2 sm:col-span-1">
            <label className="uppercase text-xs font-bold tracking-widest text-muted-foreground block mb-1.5">
              {isCable ? "Metros usados" : "Cantidad"}
            </label>
            <div className="relative">
              <Input
                type="number"
                min="1"
                {...form.register(`items.${index}.cantidad`, { valueAsNumber: true })}
                className="rounded-none border-border h-11 font-mono pr-12"
              />
              <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-muted-foreground font-bold uppercase">
                {isCable ? "m" : "u"}
              </span>
            </div>
            {form.formState.errors.items?.[index]?.cantidad && (
              <p className="text-destructive text-xs mt-1">{form.formState.errors.items[index]?.cantidad?.message}</p>
            )}
          </div>
        </div>

        {/* Número de serie (optional for cable) */}
        <div>
          <label className="uppercase text-xs font-bold tracking-widest text-muted-foreground block mb-1.5">
            Número de Serie {isCable ? "(Opcional)" : ""}
          </label>
          <Input
            placeholder={isCable ? "ID de bobina (opcional)" : "S/N · ICCID · ID"}
            {...form.register(`items.${index}.numeroSerie`)}
            className="rounded-none border-border h-11 font-mono uppercase"
          />
        </div>

        {/* Compania — SIM only */}
        {tipoMaterial === "SIM" && (
          <div>
            <label className="uppercase text-xs font-bold tracking-widest text-muted-foreground block mb-1.5">Compañía</label>
            <Input
              placeholder="Claro, Entel, Movistar..."
              {...form.register(`items.${index}.compania`)}
              className="rounded-none border-border h-11 uppercase font-bold"
            />
          </div>
        )}
      </CardContent>
    </Card>
  );
}
