import { useState, useMemo } from "react";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer } from "recharts";
import { ChevronDown, ChevronRight, Layers, MapPin } from "lucide-react";
import { useListItems } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import type { Item } from "@workspace/api-client-react";

const TIPOS_CONFIG = [
  { key: "SIM",                label: "SIM",               color: "#EAB308" },
  { key: "DONGLE",             label: "Dongle",             color: "#F97316" },
  { key: "SMARTLOGGER",        label: "SmartLogger",        color: "#22C55E" },
  { key: "ROUTER",             label: "Router",             color: "#3B82F6" },
  { key: "ANTENA",             label: "Antena",             color: "#8B5CF6" },
  { key: "TIMER_DIGITAL",      label: "Timer Digital",      color: "#EC4899" },
  { key: "REGULADOR_TENSION",  label: "Regulador",          color: "#14B8A6" },
  { key: "CABLE_COMUNICACION", label: "Cable (m)",          color: "#6B7280" },
] as const;

type TipoKey = typeof TIPOS_CONFIG[number]["key"];

interface PlantaSummary {
  nombre: string;
  fvs: string[];
  totalesPorTipo: Record<TipoKey, number>;
  totalEquipos: number;
}

function buildPlantSummaries(items: Item[]): PlantaSummary[] {
  const map = new Map<string, PlantaSummary>();
  for (const item of items) {
    if (!map.has(item.nombrePlanta)) {
      map.set(item.nombrePlanta, {
        nombre: item.nombrePlanta,
        fvs: [],
        totalesPorTipo: Object.fromEntries(TIPOS_CONFIG.map((t) => [t.key, 0])) as Record<TipoKey, number>,
        totalEquipos: 0,
      });
    }
    const p = map.get(item.nombrePlanta)!;
    const tipo = item.tipoMaterial as TipoKey;
    if (tipo in p.totalesPorTipo) {
      p.totalesPorTipo[tipo] += item.cantidad;
      p.totalEquipos += item.cantidad;
    }
  }
  return Array.from(map.values()).sort((a, b) => b.totalEquipos - a.totalEquipos);
}

export default function Plantas() {
  const { data: items, isLoading } = useListItems();
  const [expanded, setExpanded] = useState<string | null>(null);

  const plantas = useMemo(() => buildPlantSummaries(items ?? []), [items]);

  const globalTotals = useMemo(
    () =>
      TIPOS_CONFIG.map((t) => ({
        name: t.label,
        value: plantas.reduce((sum, p) => sum + p.totalesPorTipo[t.key], 0),
        color: t.color,
        key: t.key,
      })).filter((t) => t.value > 0),
    [plantas],
  );

  const totalEquipos = globalTotals.reduce((s, t) => s + t.value, 0);

  return (
    <div className="min-h-full bg-background text-foreground font-sans p-4 md:p-6">
      {/* Header */}
      <div className="mb-6 md:mb-8">
        <h1 className="text-2xl font-bold tracking-tight mb-1">Plantas Fotovoltaicas</h1>
        {isLoading ? (
          <Skeleton className="h-4 w-48 mt-1" />
        ) : (
          <p className="text-sm text-muted-foreground">
            {plantas.length} {plantas.length === 1 ? "planta" : "plantas"} · {totalEquipos} equipos totales
          </p>
        )}
      </div>

      <div className="flex flex-col md:grid md:grid-cols-[1fr_300px] gap-6 md:gap-8">
        {/* Left — expandable list */}
        <div className="space-y-2">
          {isLoading ? (
            Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="rounded-xl border border-border p-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-1.5">
                    <Skeleton className="h-4 w-40" />
                    <Skeleton className="h-3 w-24" />
                  </div>
                  <Skeleton className="h-2 w-24 rounded-full" />
                </div>
              </div>
            ))
          ) : plantas.length === 0 ? (
            <div className="rounded-xl border border-border p-8 text-center text-muted-foreground text-sm">
              No hay equipos registrados aún.
            </div>
          ) : (
            plantas.map((planta) => {
              const isOpen = expanded === planta.nombre;
              const pieData = TIPOS_CONFIG.filter((t) => planta.totalesPorTipo[t.key] > 0).map((t) => ({
                name: t.label,
                value: planta.totalesPorTipo[t.key],
                color: t.color,
              }));

              return (
                <div
                  key={planta.nombre}
                  className={`rounded-xl border transition-all ${
                    isOpen
                      ? "border-primary/40 bg-primary/5"
                      : "border-border bg-card hover:border-border/80"
                  }`}
                >
                  <button
                    onClick={() => setExpanded(isOpen ? null : planta.nombre)}
                    className="w-full flex items-center justify-between p-4 text-left"
                  >
                    <div className="flex items-center gap-3">
                      {isOpen ? (
                        <ChevronDown size={16} className="text-primary shrink-0" />
                      ) : (
                        <ChevronRight size={16} className="text-muted-foreground shrink-0" />
                      )}
                      <div>
                        <div className="font-semibold text-sm text-foreground">{planta.nombre}</div>
                        <div className="flex items-center gap-1.5 mt-0.5">
                          <MapPin size={10} className="text-muted-foreground" />
                          <span className="text-xs text-muted-foreground">
                            {planta.totalEquipos} {planta.totalEquipos === 1 ? "equipo" : "equipos"}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Mini stacked bar */}
                    <div className="flex items-center gap-3 shrink-0">
                      <div className="flex h-2 w-20 md:w-24 overflow-hidden rounded-full bg-secondary">
                        {pieData.map((d) => (
                          <div
                            key={d.name}
                            style={{ width: `${(d.value / planta.totalEquipos) * 100}%`, backgroundColor: d.color }}
                            className="h-full"
                          />
                        ))}
                      </div>
                      <span className="text-sm font-bold text-muted-foreground w-6 text-right">
                        {planta.totalEquipos}
                      </span>
                    </div>
                  </button>

                  {isOpen && (
                    <div className="px-4 pb-4 grid grid-cols-2 gap-x-6 gap-y-1.5 border-t border-border pt-4">
                      {TIPOS_CONFIG.map((tipo) => {
                        const val = planta.totalesPorTipo[tipo.key];
                        return (
                          <div key={tipo.key} className="flex items-center justify-between">
                            <div className="flex items-center gap-2">
                              <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: tipo.color }} />
                              <span className="text-xs text-muted-foreground">{tipo.label}</span>
                            </div>
                            <span className={`text-xs font-semibold ${val > 0 ? "text-foreground" : "text-muted-foreground/40"}`}>
                              {tipo.key === "CABLE_COMUNICACION" ? `${val}m` : val || "—"}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>

        {/* Right — donut + top plants */}
        <div className="space-y-4">
          {/* Donut chart */}
          <div className="rounded-xl border border-border bg-card p-5">
            <div className="flex items-center gap-2 mb-4">
              <Layers size={14} className="text-primary" />
              <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                Total global
              </span>
            </div>
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Skeleton className="w-32 h-32 rounded-full" />
              </div>
            ) : totalEquipos === 0 ? (
              <div className="text-center py-8 text-muted-foreground text-xs">Sin datos</div>
            ) : (
              <>
                <div className="relative h-44">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart>
                      <Pie
                        data={globalTotals}
                        cx="50%"
                        cy="50%"
                        innerRadius={52}
                        outerRadius={70}
                        paddingAngle={3}
                        dataKey="value"
                      >
                        {globalTotals.map((entry) => (
                          <Cell key={entry.key} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          background: "hsl(var(--card))",
                          border: "1px solid hsl(var(--border))",
                          borderRadius: 8,
                          fontSize: 12,
                          color: "hsl(var(--foreground))",
                        }}
                        itemStyle={{ color: "hsl(var(--foreground))" }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                    <span className="text-2xl font-bold text-foreground">{totalEquipos}</span>
                    <span className="text-[10px] text-muted-foreground uppercase tracking-wider">total</span>
                  </div>
                </div>
                <div className="mt-4 space-y-1.5">
                  {globalTotals.map((t) => (
                    <div key={t.key} className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: t.color }} />
                        <span className="text-xs text-muted-foreground">{t.name}</span>
                      </div>
                      <span className="text-xs font-semibold text-foreground">
                        {t.key === "CABLE_COMUNICACION" ? `${t.value}m` : t.value}
                      </span>
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>

          {/* Top plantas por equipos */}
          {!isLoading && plantas.length > 0 && (
            <div className="rounded-xl border border-border bg-card p-4">
              <div className="flex items-center gap-2 mb-3">
                <MapPin size={14} className="text-primary" />
                <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                  Top plantas
                </span>
              </div>
              {plantas.slice(0, 5).map((p) => (
                <div key={p.nombre} className="flex items-center justify-between mb-2 last:mb-0">
                  <span className="text-xs text-muted-foreground truncate max-w-[160px]">{p.nombre}</span>
                  <div className="flex items-center gap-2 shrink-0">
                    <div className="h-1 w-16 bg-secondary rounded-full overflow-hidden">
                      <div
                        className="h-full bg-primary rounded-full"
                        style={{ width: `${(p.totalEquipos / plantas[0].totalEquipos) * 100}%` }}
                      />
                    </div>
                    <span className="text-xs font-bold text-foreground w-4 text-right">{p.totalEquipos}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
