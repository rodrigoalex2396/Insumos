import { useListItems, useGetStock, useListMovements } from "@workspace/api-client-react";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Activity, Box, Database, ArrowDownRight, ArrowUpRight, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { format } from "date-fns";

const TYPE_COLORS: Record<string, string> = {
  SIM: "border-primary text-primary bg-primary/10",
  DONGLE: "border-yellow-400 text-yellow-400 bg-yellow-400/10",
  SMARTLOGGER: "border-muted-foreground text-muted-foreground bg-muted/10",
};

export default function Dashboard() {
  const { data: items, isLoading: itemsLoading } = useListItems();
  const { data: stock, isLoading: stockLoading } = useGetStock();
  const { data: movements, isLoading: movementsLoading } = useListMovements();
  const [, navigate] = useLocation();

  const recentItems = items
    ? [...items].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, 4)
    : [];

  const recentMovements = movements
    ? [...movements].sort((a, b) => new Date(b.fecha).getTime() - new Date(a.fecha).getTime()).slice(0, 4)
    : [];

  return (
    <div className="p-4 md:p-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tighter uppercase flex items-center gap-2">
            <Activity className="w-6 h-6 text-primary" />
            Dashboard
          </h1>
          <p className="text-muted-foreground uppercase text-sm tracking-widest mt-1">Field operations overview</p>
        </div>
        <Button onClick={() => navigate("/items/new")} className="rounded-none font-bold uppercase tracking-wider">
          <Plus className="w-4 h-4 mr-2" />
          Register
        </Button>
      </div>

      {/* Stock levels */}
      <div>
        <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-3">Stock Actual</p>
        <div className="grid grid-cols-3 gap-3">
          {stockLoading ? (
            Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-24 rounded-none" />)
          ) : (
            stock?.map(s => (
              <Card key={s.tipoMaterial} className="border-border bg-card rounded-none">
                <CardContent className="p-4">
                  <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-2">{s.tipoMaterial}</p>
                  <p className={`text-4xl font-bold tabular-nums ${s.stock <= 2 ? "text-destructive" : "text-primary"}`}>
                    {s.stock}
                  </p>
                  <p className="text-xs text-muted-foreground mt-1 uppercase tracking-wider">unidades</p>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Recent installs */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
              <Database className="w-3.5 h-3.5" /> Instalaciones Recientes
            </p>
            <button onClick={() => navigate("/items")} className="text-xs text-primary uppercase tracking-wider hover:underline font-bold">
              Ver todos →
            </button>
          </div>
          <Card className="border-border rounded-none">
            <CardContent className="p-0">
              {itemsLoading ? (
                <div className="p-4 space-y-3">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-8" />)}</div>
              ) : recentItems.length === 0 ? (
                <p className="p-6 text-center text-muted-foreground uppercase text-xs tracking-widest">Sin registros</p>
              ) : (
                <table className="w-full text-sm">
                  <tbody className="divide-y divide-border">
                    {recentItems.map(item => (
                      <tr
                        key={item.id}
                        onClick={() => navigate(`/items/${item.id}`)}
                        className="hover:bg-secondary/20 cursor-pointer transition-colors"
                      >
                        <td className="p-3 pl-4">
                          <span className={`inline-block px-1.5 py-0.5 border text-xs font-bold ${TYPE_COLORS[item.tipoMaterial] ?? ""}`}>
                            {item.tipoMaterial}
                          </span>
                        </td>
                        <td className="p-3 font-bold text-foreground truncate max-w-[120px]">{item.nombrePlanta}</td>
                        <td className="p-3 font-mono text-xs text-muted-foreground">{item.numeroSerie}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Recent stock movements */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest flex items-center gap-2">
              <Box className="w-3.5 h-3.5" /> Movimientos Recientes
            </p>
            <button onClick={() => navigate("/inventory")} className="text-xs text-primary uppercase tracking-wider hover:underline font-bold">
              Ver todos →
            </button>
          </div>
          <Card className="border-border rounded-none">
            <CardContent className="p-0">
              {movementsLoading ? (
                <div className="p-4 space-y-3">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-8" />)}</div>
              ) : recentMovements.length === 0 ? (
                <p className="p-6 text-center text-muted-foreground uppercase text-xs tracking-widest">Sin movimientos</p>
              ) : (
                <table className="w-full text-sm">
                  <tbody className="divide-y divide-border">
                    {recentMovements.map(m => (
                      <tr key={m.id} className="transition-colors">
                        <td className="p-3 pl-4">
                          {m.tipoMovimiento === "ENTRADA"
                            ? <ArrowDownRight className="w-4 h-4 text-emerald-500" />
                            : <ArrowUpRight className="w-4 h-4 text-destructive" />}
                        </td>
                        <td className="p-3">
                          <span className={`inline-block px-1.5 py-0.5 border text-xs font-bold ${TYPE_COLORS[m.tipoMaterial] ?? ""}`}>
                            {m.tipoMaterial}
                          </span>
                        </td>
                        <td className="p-3 font-bold text-foreground">{m.cantidad} uds</td>
                        <td className="p-3 font-mono text-xs text-muted-foreground">
                          {format(new Date(m.createdAt), "MM/dd HH:mm")}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Quick stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: "Total Instalados", value: items?.length ?? 0, sub: "equipos en campo" },
          { label: "SIM Instaladas", value: items?.filter(i => i.tipoMaterial === "SIM").length ?? 0, sub: "en plantas" },
          { label: "Dongles", value: items?.filter(i => i.tipoMaterial === "DONGLE").length ?? 0, sub: "en campo" },
          { label: "SmartLoggers", value: items?.filter(i => i.tipoMaterial === "SMARTLOGGER").length ?? 0, sub: "activos" },
        ].map(stat => (
          <Card key={stat.label} className="border-border bg-card rounded-none">
            <CardContent className="p-4">
              <p className="text-xs font-bold text-muted-foreground uppercase tracking-widest mb-1">{stat.label}</p>
              <div className="text-3xl font-bold text-foreground tabular-nums">
                {itemsLoading ? <Skeleton className="h-8 w-12" /> : stat.value}
              </div>
              <p className="text-xs text-muted-foreground mt-0.5 uppercase tracking-wider">{stat.sub}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
