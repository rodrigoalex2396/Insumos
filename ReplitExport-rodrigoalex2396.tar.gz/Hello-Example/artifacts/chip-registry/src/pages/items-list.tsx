import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useListItems } from "@workspace/api-client-react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { format } from "date-fns";
import * as XLSX from "xlsx";
import { Database, Download, Search, Plus } from "lucide-react";

export default function ItemsList() {
  const { data: items, isLoading } = useListItems();
  const [, navigate] = useLocation();
  const [search, setSearch] = useState("");
  const [filterType, setFilterType] = useState<string>("ALL");

  const filteredItems = items?.filter(item => {
    const matchesSearch =
      item.nombrePlanta.toLowerCase().includes(search.toLowerCase()) ||
      (item.numeroSerie ?? "").toLowerCase().includes(search.toLowerCase());
    const matchesType = filterType === "ALL" || item.tipoMaterial === filterType;
    return matchesSearch && matchesType;
  }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()) || [];

  const exportExcel = () => {
    if (!filteredItems.length) return;
    const ws = XLSX.utils.json_to_sheet(filteredItems.map(item => ({
      ID: item.id,
      Planta: item.nombrePlanta,
      Material: item.tipoMaterial,
      Cantidad: item.tipoMaterial === 'CABLE_COMUNICACION' ? `${item.cantidad}m` : item.cantidad,
      'Número Serie': item.numeroSerie || '-',
      Compañía: item.compania || '-',
      Notas: item.notas || '-',
      'Fecha Instalación': format(new Date(item.createdAt), 'yyyy-MM-dd HH:mm:ss')
    })));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Instalaciones");
    XLSX.writeFile(wb, `solarstock-registry-${format(new Date(), 'yyyyMMdd-HHmm')}.xlsx`);
  };

  return (
    <div className="p-4 md:p-8 space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tighter uppercase mb-1 flex items-center gap-2">
            <Database className="w-6 h-6 text-primary" />
            Equipment Registry
          </h1>
          <p className="text-muted-foreground uppercase text-sm tracking-widest">All installed components in field</p>
        </div>
        
        <div className="flex gap-2">
          <Button variant="outline" onClick={exportExcel} disabled={!filteredItems.length || isLoading} className="border-border rounded-none font-bold uppercase tracking-wider">
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
          <Button onClick={() => navigate('/items/new')} className="rounded-none font-bold uppercase tracking-wider">
            <Plus className="w-4 h-4 mr-2" />
            Register
          </Button>
        </div>
      </div>

      <Card className="border-border bg-card rounded-none">
        <div className="p-4 border-b border-border bg-secondary/30 flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input 
              placeholder="Search by plant or serial..." 
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-9 rounded-none border-border bg-background h-10"
            />
          </div>
          <div className="w-full sm:w-48 shrink-0">
            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="rounded-none border-border h-10">
                <SelectValue placeholder="All Types" />
              </SelectTrigger>
              <SelectContent className="rounded-none border-border">
                <SelectItem value="ALL">Todos</SelectItem>
                <SelectItem value="SIM">SIM</SelectItem>
                <SelectItem value="DONGLE">Dongle</SelectItem>
                <SelectItem value="SMARTLOGGER">SmartLogger</SelectItem>
                <SelectItem value="ROUTER">Router</SelectItem>
                <SelectItem value="ANTENA">Antena</SelectItem>
                <SelectItem value="TIMER_DIGITAL">Timer Digital</SelectItem>
                <SelectItem value="REGULADOR_TENSION">Regulador de Tensión</SelectItem>
                <SelectItem value="CABLE_COMUNICACION">Cable Comunicación</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm whitespace-nowrap">
              <thead>
                <tr className="border-b border-border bg-secondary/50 uppercase tracking-widest text-muted-foreground">
                  <th className="text-left p-4 font-bold text-xs">Date</th>
                  <th className="text-left p-4 font-bold text-xs">Plant</th>
                  <th className="text-left p-4 font-bold text-xs">Type</th>
                  <th className="text-left p-4 font-bold text-xs">Serial Number</th>
                  <th className="text-left p-4 font-bold text-xs">Company</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {isLoading ? (
                  <tr>
                    <td colSpan={5} className="p-8 text-center text-muted-foreground uppercase tracking-widest animate-pulse">
                      Loading data...
                    </td>
                  </tr>
                ) : filteredItems.length === 0 ? (
                  <tr>
                    <td colSpan={5} className="p-8 text-center text-muted-foreground uppercase tracking-widest">
                      No matching records
                    </td>
                  </tr>
                ) : (
                  filteredItems.map(item => (
                    <tr 
                      key={item.id} 
                      onClick={() => navigate(`/items/${item.id}`)}
                      className="hover:bg-secondary/20 cursor-pointer transition-colors"
                    >
                      <td className="p-4 text-muted-foreground font-mono">{format(new Date(item.createdAt), 'MM/dd/yyyy HH:mm')}</td>
                      <td className="p-4 font-bold">{item.nombrePlanta}</td>
                      <td className="p-4">
                        <span className={`inline-block px-2 py-1 border text-xs font-bold ${
                          item.tipoMaterial === 'SIM' ? 'border-primary text-primary bg-primary/10' :
                          item.tipoMaterial === 'DONGLE' ? 'border-accent-foreground text-accent-foreground bg-accent/10' :
                          'border-muted-foreground text-muted-foreground bg-muted/10'
                        }`}>
                          {item.tipoMaterial}
                        </span>
                      </td>
                      <td className="p-4 font-mono text-muted-foreground">{item.numeroSerie}</td>
                      <td className="p-4">{item.tipoMaterial === 'SIM' ? item.compania : '-'}</td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
