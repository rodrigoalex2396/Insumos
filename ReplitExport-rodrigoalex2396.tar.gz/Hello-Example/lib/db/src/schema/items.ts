import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const itemsTable = pgTable("items", {
  id: serial("id").primaryKey(),
  nombrePlanta: text("nombre_planta").notNull(),
  tipoMaterial: text("tipo_material").notNull(), // SIM | DONGLE | SMARTLOGGER | ROUTER | ANTENA | TIMER_DIGITAL | REGULADOR_TENSION | CABLE_COMUNICACION
  numeroSerie: text("numero_serie"),
  cantidad: integer("cantidad").notNull().default(1), // units, or meters for CABLE_COMUNICACION
  compania: text("compania"),
  notas: text("notas"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).$onUpdate(() => new Date()),
});

export const inventoryMovementsTable = pgTable("inventory_movements", {
  id: serial("id").primaryKey(),
  tipoMaterial: text("tipo_material").notNull(), // SIM | DONGLE | SMARTLOGGER
  cantidad: integer("cantidad").notNull(),
  tipoMovimiento: text("tipo_movimiento").notNull(), // ENTRADA | SALIDA
  notas: text("notas"),
  fecha: timestamp("fecha", { withTimezone: true }).notNull().defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertItemSchema = createInsertSchema(itemsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertMovementSchema = createInsertSchema(inventoryMovementsTable).omit({
  id: true,
  createdAt: true,
});

export type InsertItem = z.infer<typeof insertItemSchema>;
export type Item = typeof itemsTable.$inferSelect;
export type InsertMovement = z.infer<typeof insertMovementSchema>;
export type Movement = typeof inventoryMovementsTable.$inferSelect;
