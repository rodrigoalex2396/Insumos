import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const chipsTable = pgTable("chips", {
  id: serial("id").primaryKey(),
  nombrePlanta: text("nombre_planta").notNull(),
  fv: text("fv").notNull(),
  tipoSim: text("tipo_sim").notNull(),
  numeroSerie: text("numero_serie").notNull(),
  cobertura: text("cobertura").notNull(),
  notas: text("notas"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).$onUpdate(() => new Date()),
});

export const insertChipSchema = createInsertSchema(chipsTable).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertChip = z.infer<typeof insertChipSchema>;
export type Chip = typeof chipsTable.$inferSelect;
